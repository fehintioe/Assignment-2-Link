﻿namespace Assignment2.Models
{
    public class Category
    {
        public int CategoryId { get; set; }  // Primary Key
        public string Name { get; set; }
        public string Description { get; set; }
        public DateTime CreatedDate { get; set; }

        // Navigation property for related Products
        public ICollection<Producr> Products { get; set; }
    }
}

